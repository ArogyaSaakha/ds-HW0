<a href="https://github.com/DenverCoder1/readme-typing-svg"><img src="https://readme-typing-svg.herokuapp.com?lines=This+Is+Gaim;Your+Worst+Nightmare;Escape+Before+Its+Too+Late&center=true&width=500&height=50"></a>

***This is Gaim***
<br>
**Authors:** *@mich5250 & @Arogya*
<br><br>
An escape room game made with Java Object-Oriented Programming. In this game, you are in a hellish world. You must find your way out before it's too late (i.e your time runs out and you die X/ ). Random things increase your time so find out what they are. Be careful, be cautious, and be smart.
<br><br>
Remember: The world moves faster than you think heheheheheheheheh.

Reflections can be found in [Reflection.md](Reflection.md)

<!-- Animation from @DenverCoder1 on Github -->
